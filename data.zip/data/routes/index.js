
var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/move/:movement', function(req, res, next) {

  let result = "victory";
  const randNumber = Math.floor((Math.random() * 3) + 1);
  //switch = L'instruction switch évalue une expression et, selon le résultat obtenu et le cas associé, exécute les instructions correspondantes.
  switch (randNumber) {
    case 1:
    // req.params.movement transforme /move/:movement en en /move/:rock || paper || scissors
      if(req.params.movement == 'rock') {
        result = "defeat";
      } else if (req.params.movement == 'paper') {
        result = "tie";
      }
      break;
    case 2:
      if(req.params.movement == 'scissors') {
        result = "defeat";
      } else if (req.params.movement == 'rock') {
        result = "tie";
      }
      break;
    case 3:
      if(req.params.movement == 'paper') {
        result = "defeat";
      } else if (req.params.movement == 'scissors') {
        result = "tie";
      }
      break;
  }
  res.send(result);
});
// module = super globale dans le file
// exports = variable module.exports, ce que l'on exporte quand le fichier est required.
module.exports = router;
